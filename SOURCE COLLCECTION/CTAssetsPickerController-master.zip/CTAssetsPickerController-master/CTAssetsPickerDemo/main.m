//
//  main.m
//  CTAssetsPickerDemo
//
//  Created by Clement CN Tsang on 23/9/13.
//  Copyright (c) 2013 Clement T. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CTAppDelegate class]));
    }
}
