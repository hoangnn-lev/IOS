//
//  SettingsCell1.h
//  ADVFlatUI
//
//  Created by Tope on 05/06/2013.
//  Copyright (c) 2013 App Design Vault. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsCell1 : UITableViewCell

@property (nonatomic, strong) IBOutlet UIView* bgView;

@property (nonatomic, strong) IBOutlet UIView* separatorLineView;

@property (nonatomic, strong) IBOutlet UILabel* settingTitle;

@end
